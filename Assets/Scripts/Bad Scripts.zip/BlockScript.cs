﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockScript : MonoBehaviour
{
    Vector3 allDirs;
    void Start()
    {
        //X
        allDirs.Add(new Vector3(transform.position.x+1,transform.position.y,transform.position.z));
        allDirs.Add(new Vector3(transform.position.x-1,transform.position.y,transform.position.z));
        //Y
        allDirs.Add(new Vector3(transform.position.x,transform.position.y+1,transform.position.z));
        allDirs.Add(new Vector3(transform.position.x,transform.position.y-1,transform.position.z));
        //X
        allDirs.Add(new Vector3(transform.position.x,transform.position.y,transform.position.z+1));
        allDirs.Add(new Vector3(transform.position.x,transform.position.y,transform.position.z-1));
        
        CheckSides();
    }

    public void CheckSides()
    {
        foreach (Transform child in transform.parent)
        {
            int i = 6;
            while(i > 0 )
            {
                i--;
                if(allDirs[i] = child.transform.position)
                {
                     
                }
            }
        }
    }

    void OnMouseDown()
    {
        Destroy(this.gameObject);
    }
}
